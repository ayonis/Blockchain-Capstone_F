
var json = require('./proof.json');
var verifier = artifacts.require('verifier');


contract('verifier', accounts => {

    const acc0 = accounts[0];

    describe('verifing  TX with correct proof and incorrect proof', function () {
        beforeEach(async function () {
            this.contract = await verifier.new({from: acc0});
        })

        it('Testing with correct proof', async function () {
          let isVerified = await this.contract.verifyTx.call(json.proof.A,json.proof.A_p,json.proof.B,json.proof.B_p,json.proof.C,json.proof.C_p,json.proof.H,json.proof.K,json.input);
          assert.equal(isVerified, true,"verification Error : The proof is incorrect or invalid")
        })

        it('Testing with incorrect proof', async function () {

            var incorrectProofJson = { proof:
        {
            A:["0x3ea42e129172c284551d1cef57121895601d5ff475160185c62fc5f8059500d", "0x662981c54f1de4773ee9255c503ff523ee98a35db3c13d5c39390293d09fd51"],
            A_p:["0x158f4107728fa8e56a5a88fe4f5cc64e41969db21dc1b40a962660b96fa06dc9", "0x258fae8a49876ccace72652add8ccc9e48ae27715c15ce2d7cd54cb79c825670"],
            B:
                [["0x2b75d2409b7591e2df9126876f528014f8def4fb057221a2db0d63ada3a75175", "0x110de3317287098e9fca5ea1c09b49eeca3416d5135578789c027b045b92e44c"], ["0x2700b74ac198389f7fec24fc52297321e3676cc20b8c71d8286840b7b8ffd9b6", "0x1737fe6b9a41a37a839cc04a595eaf7cb7c6ec909fc226cae2135a1753033863"]],
            
            B_p:["0x479d28885b58472bc8102d681f7fede51d623528510a594135857ac2b476dad", "0xe9a7b963f66752950a8af794b6b802b0ee6d00ff2d16b8b81be5c9047451f2e"],
            C:["0x8a5c95f498c036affb1af76f28af3a436bcc3be3e81b9e5d18acacb2964fc3e", "0x202d7da55fd6b2aff9d5a2f7a0450f96854c87a4db6011fd8d5b6fd53f0e89d6"],
            C_p:["0x1f4fe414f3e641c3ba0be1bf974fd77ee947326fdc33b593b1b34817abfdcdc0", "0x302c2462fabf9b821bab213fed2bff81f549d388388e42a18ad89e087521aa97"],
            H :["0x1cdc3830c90eabf5fd974bd2355beebb6ab32b132834a72aca1a3ad2fcf2876e", "0x23381470969c0174bcd3adc15285794bc652c83e520f7d77516813b33610a2da"],
            K:["0x9b455e61b9c8898d19f06e9c299ee8428ebc2f958b16bff9342e2175a9e74eb", "0x25c73510539d4df89f1643f3bef27da666e0e8fc8425a4af0e38efafe6433c1f"]
        },
        input:[9,1]}
    
              let isVerified = await this.contract.verifyTx.call(incorrectProofJson.proof.A,incorrectProofJson.proof.A_p, incorrectProofJson.proof.B,incorrectProofJson.proof.B_p,incorrectProofJson.proof.C,incorrectProofJson.proof.C_p,incorrectProofJson.proof.H,incorrectProofJson.proof.K,[5,1])
              assert.equal(isVerified,false,"Incorrect proofing")
    
            });

    });



})
