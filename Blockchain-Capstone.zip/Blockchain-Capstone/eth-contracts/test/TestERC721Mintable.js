var ERC721Mintable = artifacts.require('ERC721Mintable');

contract('TestERC721Mintable', accounts => {

    const acc1 = accounts[0];
    const acc2 = accounts[1];
    const acc3 = accounts[2];
    const acc4 = accounts[3];
    const acc5 = accounts[4];
    const acc6 = accounts[5];
    const symbol = "EGYTKN";
    const name = "EGY_House_Token";


    describe('Test ERC721 Functions', function () {
        beforeEach(async function () { 
            this.contract = await ERC721Mintable.new(name ,symbol , {from: acc1});

            // TODO: mint multiple tokens
            for(let i = 0; i <= 10; i++){
              let status = await this.contract.mint(acc2,i,{from:acc1});
            }

        })

        it('should return total supply', async function () { 
            let totalTokens = await this.contract.totalSupply();
           
            assert.equal(totalTokens,11,"Total Number of token is incorrect for total supply");
        })

        it('should get token balance', async function () { 
            let balance = await this.contract.balanceOf(acc2);
            
            assert.equal(balance, 11, "token balance is Incorrect for This Address");
        })

        // token uri should be complete i.e: https://s3-us-west-2.amazonaws.com/udacity-blockchain/capstone/1
        it('should return token uri', async function () {
          let URI = await this.contract.baseTokenURI();
          assert.equal(URI,"https://s3-us-west-2.amazonaws.com/udacity-blockchain/capstone/","returned Token uri is incorrect ");
        })

        it('should transfer token from one owner to another', async function () { 
            await this.contract.transferFrom(acc2 ,acc3 ,1,{from:acc2});
            let newOwner = await this.contract.ownerOf(1);
            assert.equal(newOwner,acc3 ,"Incorrect token Transfer 'Token Not Transfered'");
            
            await this.contract.transferFrom(acc2 ,acc4 ,2,{from:acc2});
            newOwner = await this.contract.ownerOf(2);
            assert.equal(newOwner,acc4 ,"Incorrect token Transfer 'Token Not Transfered'");
        })
    });

    describe('have ownership properties', function () {
        beforeEach(async function () { 
            this.contract = await ERC721Mintable.new(name,symbol,{from: acc1});
        })

        it('should fail when minting when address is not contract owner', async function () { 
            let mintingStat =true;
            try{
                let mintingStat = await this.contract.mint(acc5,13,{from:acc5});
            }catch(e){
                 mintingStat = false;
            }
                assert.equal(mintingStat,false ,"Error : Only Owner who can mint");
        })

        it('should return contract owner', async function () { 
            let contractOwner = await this.contract.owner.call();
            assert.equal(contractOwner, acc1,"Owner is not correct");
        })

    });
})